import '/flutter_flow/flutter_flow_util.dart';
import 'points_redeemer_widget.dart' show PointsRedeemerWidget;
import 'package:flutter/material.dart';

class PointsRedeemerModel extends FlutterFlowModel<PointsRedeemerWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
