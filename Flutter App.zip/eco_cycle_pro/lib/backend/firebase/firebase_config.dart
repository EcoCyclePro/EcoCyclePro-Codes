import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyD96EIkVQK2AnfeHFbu0of9vrc14kdDjqE",
            authDomain: "eco-cycle-pro-q6ldp9.firebaseapp.com",
            projectId: "eco-cycle-pro-q6ldp9",
            storageBucket: "eco-cycle-pro-q6ldp9.appspot.com",
            messagingSenderId: "502257319312",
            appId: "1:502257319312:web:e3cb0e193ece5ff2438715"));
  } else {
    await Firebase.initializeApp();
  }
}
