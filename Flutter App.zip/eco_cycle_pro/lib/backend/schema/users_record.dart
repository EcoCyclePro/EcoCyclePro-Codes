import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "Birth_Date" field.
  DateTime? _birthDate;
  DateTime? get birthDate => _birthDate;
  bool hasBirthDate() => _birthDate != null;

  // "Gender" field.
  String? _gender;
  String get gender => _gender ?? '';
  bool hasGender() => _gender != null;

  // "Full_Name" field.
  String? _fullName;
  String get fullName => _fullName ?? '';
  bool hasFullName() => _fullName != null;

  // "Points_Balance" field.
  double? _pointsBalance;
  double get pointsBalance => _pointsBalance ?? 0.0;
  bool hasPointsBalance() => _pointsBalance != null;

  // "Vouchers" field.
  double? _vouchers;
  double get vouchers => _vouchers ?? 0.0;
  bool hasVouchers() => _vouchers != null;

  // "Redeem_History" field.
  List<RedeemerStruct>? _redeemHistory;
  List<RedeemerStruct> get redeemHistory => _redeemHistory ?? const [];
  bool hasRedeemHistory() => _redeemHistory != null;

  // "Recycle_Number" field.
  double? _recycleNumber;
  double get recycleNumber => _recycleNumber ?? 0.0;
  bool hasRecycleNumber() => _recycleNumber != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _birthDate = snapshotData['Birth_Date'] as DateTime?;
    _gender = snapshotData['Gender'] as String?;
    _fullName = snapshotData['Full_Name'] as String?;
    _pointsBalance = castToType<double>(snapshotData['Points_Balance']);
    _vouchers = castToType<double>(snapshotData['Vouchers']);
    _redeemHistory = getStructList(
      snapshotData['Redeem_History'],
      RedeemerStruct.fromMap,
    );
    _recycleNumber = castToType<double>(snapshotData['Recycle_Number']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  DateTime? birthDate,
  String? gender,
  String? fullName,
  double? pointsBalance,
  double? vouchers,
  double? recycleNumber,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'Birth_Date': birthDate,
      'Gender': gender,
      'Full_Name': fullName,
      'Points_Balance': pointsBalance,
      'Vouchers': vouchers,
      'Recycle_Number': recycleNumber,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.birthDate == e2?.birthDate &&
        e1?.gender == e2?.gender &&
        e1?.fullName == e2?.fullName &&
        e1?.pointsBalance == e2?.pointsBalance &&
        e1?.vouchers == e2?.vouchers &&
        listEquality.equals(e1?.redeemHistory, e2?.redeemHistory) &&
        e1?.recycleNumber == e2?.recycleNumber;
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.birthDate,
        e?.gender,
        e?.fullName,
        e?.pointsBalance,
        e?.vouchers,
        e?.redeemHistory,
        e?.recycleNumber
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
