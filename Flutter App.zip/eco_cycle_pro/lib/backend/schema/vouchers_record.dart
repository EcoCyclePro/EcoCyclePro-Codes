import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class VouchersRecord extends FirestoreRecord {
  VouchersRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "Provider_Name" field.
  String? _providerName;
  String get providerName => _providerName ?? '';
  bool hasProviderName() => _providerName != null;

  // "Provider_Image" field.
  String? _providerImage;
  String get providerImage => _providerImage ?? '';
  bool hasProviderImage() => _providerImage != null;

  // "Voucher_Price" field.
  double? _voucherPrice;
  double get voucherPrice => _voucherPrice ?? 0.0;
  bool hasVoucherPrice() => _voucherPrice != null;

  // "Provider_Offer" field.
  String? _providerOffer;
  String get providerOffer => _providerOffer ?? '';
  bool hasProviderOffer() => _providerOffer != null;

  // "Offer_Value" field.
  String? _offerValue;
  String get offerValue => _offerValue ?? '';
  bool hasOfferValue() => _offerValue != null;

  void _initializeFields() {
    _providerName = snapshotData['Provider_Name'] as String?;
    _providerImage = snapshotData['Provider_Image'] as String?;
    _voucherPrice = castToType<double>(snapshotData['Voucher_Price']);
    _providerOffer = snapshotData['Provider_Offer'] as String?;
    _offerValue = snapshotData['Offer_Value'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Vouchers');

  static Stream<VouchersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => VouchersRecord.fromSnapshot(s));

  static Future<VouchersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => VouchersRecord.fromSnapshot(s));

  static VouchersRecord fromSnapshot(DocumentSnapshot snapshot) =>
      VouchersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static VouchersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      VouchersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'VouchersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is VouchersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createVouchersRecordData({
  String? providerName,
  String? providerImage,
  double? voucherPrice,
  String? providerOffer,
  String? offerValue,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Provider_Name': providerName,
      'Provider_Image': providerImage,
      'Voucher_Price': voucherPrice,
      'Provider_Offer': providerOffer,
      'Offer_Value': offerValue,
    }.withoutNulls,
  );

  return firestoreData;
}

class VouchersRecordDocumentEquality implements Equality<VouchersRecord> {
  const VouchersRecordDocumentEquality();

  @override
  bool equals(VouchersRecord? e1, VouchersRecord? e2) {
    return e1?.providerName == e2?.providerName &&
        e1?.providerImage == e2?.providerImage &&
        e1?.voucherPrice == e2?.voucherPrice &&
        e1?.providerOffer == e2?.providerOffer &&
        e1?.offerValue == e2?.offerValue;
  }

  @override
  int hash(VouchersRecord? e) => const ListEquality().hash([
        e?.providerName,
        e?.providerImage,
        e?.voucherPrice,
        e?.providerOffer,
        e?.offerValue
      ]);

  @override
  bool isValidKey(Object? o) => o is VouchersRecord;
}
