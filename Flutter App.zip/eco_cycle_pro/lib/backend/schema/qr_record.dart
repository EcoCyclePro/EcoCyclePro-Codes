import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class QrRecord extends FirestoreRecord {
  QrRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "QRCode" field.
  String? _qRCode;
  String get qRCode => _qRCode ?? '';
  bool hasQRCode() => _qRCode != null;

  // "Redeemed" field.
  bool? _redeemed;
  bool get redeemed => _redeemed ?? false;
  bool hasRedeemed() => _redeemed != null;

  void _initializeFields() {
    _qRCode = snapshotData['QRCode'] as String?;
    _redeemed = snapshotData['Redeemed'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('QR');

  static Stream<QrRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => QrRecord.fromSnapshot(s));

  static Future<QrRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => QrRecord.fromSnapshot(s));

  static QrRecord fromSnapshot(DocumentSnapshot snapshot) => QrRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static QrRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      QrRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'QrRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is QrRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createQrRecordData({
  String? qRCode,
  bool? redeemed,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'QRCode': qRCode,
      'Redeemed': redeemed,
    }.withoutNulls,
  );

  return firestoreData;
}

class QrRecordDocumentEquality implements Equality<QrRecord> {
  const QrRecordDocumentEquality();

  @override
  bool equals(QrRecord? e1, QrRecord? e2) {
    return e1?.qRCode == e2?.qRCode && e1?.redeemed == e2?.redeemed;
  }

  @override
  int hash(QrRecord? e) => const ListEquality().hash([e?.qRCode, e?.redeemed]);

  @override
  bool isValidKey(Object? o) => o is QrRecord;
}
