// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RedeemerStruct extends FFFirebaseStruct {
  RedeemerStruct({
    String? serviceName,
    double? serviceCost,
    DateTime? redeemDate,
    String? discountValue,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _serviceName = serviceName,
        _serviceCost = serviceCost,
        _redeemDate = redeemDate,
        _discountValue = discountValue,
        super(firestoreUtilData);

  // "Service_Name" field.
  String? _serviceName;
  String get serviceName => _serviceName ?? '';
  set serviceName(String? val) => _serviceName = val;
  bool hasServiceName() => _serviceName != null;

  // "Service_Cost" field.
  double? _serviceCost;
  double get serviceCost => _serviceCost ?? 0.0;
  set serviceCost(double? val) => _serviceCost = val;
  void incrementServiceCost(double amount) =>
      _serviceCost = serviceCost + amount;
  bool hasServiceCost() => _serviceCost != null;

  // "Redeem_Date" field.
  DateTime? _redeemDate;
  DateTime? get redeemDate => _redeemDate;
  set redeemDate(DateTime? val) => _redeemDate = val;
  bool hasRedeemDate() => _redeemDate != null;

  // "Discount_Value" field.
  String? _discountValue;
  String get discountValue => _discountValue ?? '';
  set discountValue(String? val) => _discountValue = val;
  bool hasDiscountValue() => _discountValue != null;

  static RedeemerStruct fromMap(Map<String, dynamic> data) => RedeemerStruct(
        serviceName: data['Service_Name'] as String?,
        serviceCost: castToType<double>(data['Service_Cost']),
        redeemDate: data['Redeem_Date'] as DateTime?,
        discountValue: data['Discount_Value'] as String?,
      );

  static RedeemerStruct? maybeFromMap(dynamic data) =>
      data is Map ? RedeemerStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'Service_Name': _serviceName,
        'Service_Cost': _serviceCost,
        'Redeem_Date': _redeemDate,
        'Discount_Value': _discountValue,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'Service_Name': serializeParam(
          _serviceName,
          ParamType.String,
        ),
        'Service_Cost': serializeParam(
          _serviceCost,
          ParamType.double,
        ),
        'Redeem_Date': serializeParam(
          _redeemDate,
          ParamType.DateTime,
        ),
        'Discount_Value': serializeParam(
          _discountValue,
          ParamType.String,
        ),
      }.withoutNulls;

  static RedeemerStruct fromSerializableMap(Map<String, dynamic> data) =>
      RedeemerStruct(
        serviceName: deserializeParam(
          data['Service_Name'],
          ParamType.String,
          false,
        ),
        serviceCost: deserializeParam(
          data['Service_Cost'],
          ParamType.double,
          false,
        ),
        redeemDate: deserializeParam(
          data['Redeem_Date'],
          ParamType.DateTime,
          false,
        ),
        discountValue: deserializeParam(
          data['Discount_Value'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'RedeemerStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is RedeemerStruct &&
        serviceName == other.serviceName &&
        serviceCost == other.serviceCost &&
        redeemDate == other.redeemDate &&
        discountValue == other.discountValue;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([serviceName, serviceCost, redeemDate, discountValue]);
}

RedeemerStruct createRedeemerStruct({
  String? serviceName,
  double? serviceCost,
  DateTime? redeemDate,
  String? discountValue,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    RedeemerStruct(
      serviceName: serviceName,
      serviceCost: serviceCost,
      redeemDate: redeemDate,
      discountValue: discountValue,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

RedeemerStruct? updateRedeemerStruct(
  RedeemerStruct? redeemer, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    redeemer
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addRedeemerStructData(
  Map<String, dynamic> firestoreData,
  RedeemerStruct? redeemer,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (redeemer == null) {
    return;
  }
  if (redeemer.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && redeemer.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final redeemerData = getRedeemerFirestoreData(redeemer, forFieldValue);
  final nestedData = redeemerData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = redeemer.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getRedeemerFirestoreData(
  RedeemerStruct? redeemer, [
  bool forFieldValue = false,
]) {
  if (redeemer == null) {
    return {};
  }
  final firestoreData = mapToFirestore(redeemer.toMap());

  // Add any Firestore field values
  redeemer.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getRedeemerListFirestoreData(
  List<RedeemerStruct>? redeemers,
) =>
    redeemers?.map((e) => getRedeemerFirestoreData(e, true)).toList() ?? [];
