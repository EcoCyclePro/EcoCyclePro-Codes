import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MissionsRecord extends FirestoreRecord {
  MissionsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "Task" field.
  String? _task;
  String get task => _task ?? '';
  bool hasTask() => _task != null;

  // "Times" field.
  int? _times;
  int get times => _times ?? 0;
  bool hasTimes() => _times != null;

  // "Reward" field.
  String? _reward;
  String get reward => _reward ?? '';
  bool hasReward() => _reward != null;

  void _initializeFields() {
    _task = snapshotData['Task'] as String?;
    _times = castToType<int>(snapshotData['Times']);
    _reward = snapshotData['Reward'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Missions');

  static Stream<MissionsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MissionsRecord.fromSnapshot(s));

  static Future<MissionsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => MissionsRecord.fromSnapshot(s));

  static MissionsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      MissionsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MissionsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MissionsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MissionsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MissionsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMissionsRecordData({
  String? task,
  int? times,
  String? reward,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Task': task,
      'Times': times,
      'Reward': reward,
    }.withoutNulls,
  );

  return firestoreData;
}

class MissionsRecordDocumentEquality implements Equality<MissionsRecord> {
  const MissionsRecordDocumentEquality();

  @override
  bool equals(MissionsRecord? e1, MissionsRecord? e2) {
    return e1?.task == e2?.task &&
        e1?.times == e2?.times &&
        e1?.reward == e2?.reward;
  }

  @override
  int hash(MissionsRecord? e) =>
      const ListEquality().hash([e?.task, e?.times, e?.reward]);

  @override
  bool isValidKey(Object? o) => o is MissionsRecord;
}
