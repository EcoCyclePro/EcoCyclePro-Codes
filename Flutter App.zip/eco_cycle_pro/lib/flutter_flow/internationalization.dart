import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'ar'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? arText = '',
  }) =>
      [enText, arText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    final language = locale.toString();
    return FFLocalizations.languages().contains(
      language.endsWith('_')
          ? language.substring(0, language.length - 1)
          : language,
    );
  }

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // Home
  {
    '6qonphzq': {
      'en': 'My Points: ',
      'ar': 'نقاطي:',
    },
    'gfln81bu': {
      'en': 'Current Missions',
      'ar': 'المهمات الحالية',
    },
    '2q2lkvg3': {
      'en': '0%',
      'ar': '40%',
    },
    'nlqe7z7a': {
      'en': 'QR Code Scanner',
      'ar': 'الماسح الضوئي لرمز الاستجابة السريعة',
    },
    'hkvqbvub': {
      'en': 'Cancel',
      'ar': 'الغاء',
    },
    'zbpjt9jt': {
      'en': 'Home',
      'ar': 'الصفحة الرئيسية',
    },
    'jg4hoha4': {
      'en': 'Home',
      'ar': 'الصفحة الرئيسية',
    },
  },
  // SplashScreen
  {
    'xdnhwlmi': {
      'en': 'Get Started',
      'ar': 'البدء',
    },
    'js0b1s8y': {
      'en': 'Login',
      'ar': 'تسجيل الدخول',
    },
    'mpvrlhjh': {
      'en': 'Sign Up',
      'ar': 'اشتراك',
    },
    'n5nljcs1': {
      'en': 'Home',
      'ar': 'الصفحة الرئيسية',
    },
  },
  // login
  {
    'k4gyh6gv': {
      'en': 'Hi, Welcome Back! 👋',
      'ar': 'اهلا، مرحبًا بعودتك! 👋',
    },
    'kqf7r3w7': {
      'en': 'Email',
      'ar': 'البريد إلكتروني',
    },
    'iutyrx47': {
      'en': 'Email Address',
      'ar': 'عنوان البريد الإلكتروني',
    },
    'kb4pdmmr': {
      'en': 'Password',
      'ar': 'كلمة المرور',
    },
    'ao4r423m': {
      'en': 'Enter Your Password',
      'ar': 'ادخل كلمة المرور',
    },
    '0rp1g9v6': {
      'en': 'Forgot Password?',
      'ar': 'هل نسيت كلمة السر؟',
    },
    'dkvuy33a': {
      'en': 'Login',
      'ar': 'تسجيل الدخول',
    },
    'twvpwdts': {
      'en': 'Please authenticate to login',
      'ar': 'يرجى المصادقة لتسجيل الدخول',
    },
    'i2ylited': {
      'en': '-------- Or login with --------',
      'ar': '-------- أو تسجيل الدخول باستخدام --------',
    },
    'xdc59wd1': {
      'en': 'Login with Facebook',
      'ar': 'تسجيل الدخول باستخدام الفيسبوك',
    },
    'p3078wyw': {
      'en': 'Login with Google ',
      'ar': 'تسجيل الدخول عبر جوجل',
    },
    'me5tm5kt': {
      'en': 'Don’t have an account ? ',
      'ar': 'ليس لديك حساب ؟',
    },
    'a8j78xb5': {
      'en': 'JOIN US NOW',
      'ar': 'انضم إلينا الآن',
    },
    'z71hxf6j': {
      'en': 'Home',
      'ar': 'الصفحة الرئيسية',
    },
  },
  // ForgotPassword
  {
    'ry45yo1r': {
      'en': 'Forgot Password',
      'ar': 'هل نسيت كلمة السر',
    },
    'hqzn0fwf': {
      'en':
          'Dont worry! It occurs. Please enter the email address linked with your account',
      'ar':
          'لا تقلق! هذا يحدث. الرجاء إدخال عنوان البريد الإلكتروني المرتبط بحسابك',
    },
    '6svl7fhy': {
      'en': 'Email',
      'ar': 'بريد إلكتروني',
    },
    'ayk8c28w': {
      'en': 'Email Address',
      'ar': 'عنوان البريد الإلكتروني',
    },
    '116hy4da': {
      'en': 'Send Reset Email',
      'ar': 'إرسال إعادة تعيين البريد الإلكتروني',
    },
    'vh0u99mn': {
      'en': 'Home',
      'ar': 'الصفحة الرئيسية',
    },
  },
  // SignUp
  {
    'ebcy53ne': {
      'en': 'Create an account',
      'ar': 'إنشاء حساب جديد',
    },
    '07u7lkw5': {
      'en': 'Connect with your friends today!',
      'ar': 'تواصل مع أصدقائك اليوم!',
    },
    'f38c5b7o': {
      'en': 'Enter Your Email',
      'ar': 'أدخل بريدك الإلكتروني',
    },
    '7phbmf6k': {
      'en': 'Enter Your Password',
      'ar': 'ادخل كلمة المرور الخاصة بك',
    },
    'njflyiuj': {
      'en': 'Renter Your Password',
      'ar': 'قم بأعادة ادخال كلمة المرور الخاصة بك',
    },
    'tps25pxy': {
      'en': 'Email is required',
      'ar': 'البريد الالكتروني مطلوب',
    },
    'bsq0f9l5': {
      'en': 'Invalid email address',
      'ar': 'عنوان البريد الإلكتروني غير صالح',
    },
    'tzucrxmb': {
      'en': 'Please choose an option from the dropdown',
      'ar': 'يرجى اختيار خيار من القائمة المنسدلة',
    },
    '5ln2x0ak': {
      'en': 'Password is required',
      'ar': 'كلمة المرور مطلوبة',
    },
    'yb4dt265': {
      'en': 'At least 8 characters long allowed',
      'ar': 'مسموح بما لا يقل عن 8 أحرف',
    },
    'qi2cz2os': {
      'en': 'Use upper and lowercase, special character, numbers',
      'ar': 'استخدم الأحرف الكبيرة والصغيرة والأحرف الخاصة والأرقام',
    },
    '0wqscjc3': {
      'en': 'Please choose an option from the dropdown',
      'ar': 'يرجى اختيار خيار من القائمة المنسدلة',
    },
    '5cj2thvx': {
      'en': 'Please Confirm Password',
      'ar': 'الرجاء تأكيد كلمة المرور',
    },
    '3srp8h7u': {
      'en': 'At least 8 characters long allowed',
      'ar': 'مسموح بما لا يقل عن 8 أحرف',
    },
    'mgbqx9s0': {
      'en': 'Use upper and lowercase, special character, numbers',
      'ar': 'استخدم الأحرف الكبيرة والصغيرة والأحرف الخاصة والأرقام',
    },
    'v4s6gbi1': {
      'en': 'Please choose an option from the dropdown',
      'ar': 'يرجى اختيار خيار من القائمة المنسدلة',
    },
    't4pnxeau': {
      'en': 'Sign Up',
      'ar': 'اشتراك',
    },
    '339049n4': {
      'en': '-------- Or Sign up with --------',
      'ar': '-------- أو قم بالتسجيل باستخدام --------',
    },
    'arwij4yz': {
      'en': 'Sign up with Facebook',
      'ar': 'اشترك عبر حساب فايسبوك',
    },
    'uq8e1hpw': {
      'en': 'Sign up with Google ',
      'ar': 'قم بالتسجيل مع جوجل',
    },
    's89o6nzd': {
      'en': 'Already have an account? ',
      'ar': 'هل لديك حساب؟',
    },
    'j0q4dgo6': {
      'en': 'Login',
      'ar': 'تسجيل الدخول',
    },
    '8n2e190g': {
      'en': 'Home',
      'ar': 'الصفحة الرئيسية',
    },
  },
  // Profiles
  {
    'ek3tteoz': {
      'en': 'General',
      'ar': 'عام',
    },
    '806pytet': {
      'en': 'Account Information',
      'ar': 'معلومات الحساب',
    },
    '7ahfhg6k': {
      'en': 'Transaction History',
      'ar': 'تاريخ المعاملات',
    },
    'iwbalu0i': {
      'en': 'Settings',
      'ar': 'إعدادات',
    },
    'srvta47z': {
      'en': 'Support',
      'ar': 'الدعم',
    },
    'oga9c647': {
      'en': 'About Us',
      'ar': 'معلومات عنا',
    },
    '2sti8zar': {
      'en': 'FAQ',
      'ar': 'التعليمات',
    },
    'qwt36v1t': {
      'en': 'Help',
      'ar': 'مساعدة',
    },
    'ham1djnu': {
      'en': 'Logout',
      'ar': 'تسجيل خروج',
    },
    'q6mdpw1l': {
      'en': 'Profile',
      'ar': 'حساب تعريفي',
    },
    '0vkqmvct': {
      'en': 'Profile',
      'ar': 'حساب تعريفي',
    },
  },
  // Account
  {
    'wjr83s54': {
      'en': 'PROFILE',
      'ar': 'حساب تعريفي',
    },
    'y4w04636': {
      'en': 'Change profile picture',
      'ar': 'تغيير الصورة الشخصية',
    },
    '2l2in250': {
      'en': 'Full Name',
      'ar': 'الاسم الكامل',
    },
    'ws9zm8tk': {
      'en': 'Username',
      'ar': 'اسم المستخدم',
    },
    'uu3xnbtr': {
      'en': 'PERSONAL INFO',
      'ar': 'معلومات شخصية',
    },
    'b0ceohgk': {
      'en': 'User ID',
      'ar': 'معرف المستخدم',
    },
    'kyayxawf': {
      'en': 'Date of Birth',
      'ar': 'تاريخ الميلاد',
    },
    'pi8w8ad1': {
      'en': 'Phone Number',
      'ar': 'رقم التليفون',
    },
    'g3uixc2l': {
      'en': 'Email',
      'ar': 'بريد إلكتروني',
    },
    'bpipd9zh': {
      'en': 'Gender',
      'ar': 'النوع',
    },
    's8dylpu3': {
      'en': 'Account Information',
      'ar': 'معلومات الحساب',
    },
    'qm2h4pbd': {
      'en': 'Profile',
      'ar': 'حساب تعريفي',
    },
  },
  // Vouchers
  {
    'eyg4ixho': {
      'en': 'Points',
      'ar': 'نقاط',
    },
    '64axnemg': {
      'en': 'Point History',
      'ar': 'تاريخ النقطة',
    },
    '0ag422we': {
      'en': '25 % discount voucher',
      'ar': 'قسيمة خصم 25%',
    },
    'mlz9uo6m': {
      'en': 'Redeem',
      'ar': 'استرداد',
    },
    'kgc35hth': {
      'en': '25 % discount voucher',
      'ar': 'قسيمة خصم 25%',
    },
    'f5ssdayw': {
      'en': '25 % discount voucher',
      'ar': 'قسيمة خصم 25%',
    },
    'k3v5ed7f': {
      'en': '1.000 Points',
      'ar': '1.000 نقطة',
    },
    '8lnwyjtx': {
      'en': 'Redeem',
      'ar': 'استرداد',
    },
    '5quzh8oj': {
      'en': 'Vouchers',
      'ar': 'قسائم',
    },
    '5c613r5d': {
      'en': 'Voucher',
      'ar': 'فاتورة',
    },
  },
  // CompleteAccount
  {
    'z2b2yea6': {
      'en': 'Complete Your account',
      'ar': 'أكمل حسابك',
    },
    'g2g0b0cz': {
      'en': 'Enter Your Full Name',
      'ar': 'أدخل اسمك الكامل',
    },
    'qhcxow4d': {
      'en': 'Enter Your Username',
      'ar': 'أدخل اسم المستخدم الخاص بك',
    },
    'nm1t2w4p': {
      'en': 'Enter Your Phone Number',
      'ar': 'أدخل رقم هاتفك',
    },
    'kail6wt2': {
      'en': 'Male',
      'ar': 'ذكر',
    },
    'ckjo7gfu': {
      'en': 'Female',
      'ar': 'أنثى',
    },
    'ytlkkxtq': {
      'en': 'Choose Your Gender',
      'ar': 'اختيار جنسك',
    },
    'o9cde8in': {
      'en': 'Search for an item...',
      'ar': 'البحث عن عنصر...',
    },
    'ozmskh7y': {
      'en': 'Select Birth Date',
      'ar': 'اختر تاريخ الميلاد',
    },
    '4tqrcvxp': {
      'en': 'Upload Your photo',
      'ar': 'رفع صورتك',
    },
    '4ook0b02': {
      'en': 'Continue',
      'ar': 'اكمل',
    },
    'mdy62u3g': {
      'en': 'Home',
      'ar': 'الصفحة الرئيسية',
    },
  },
  // History
  {
    'elbzcacx': {
      'en': 'Search for something',
      'ar': 'ابحث عن شيء ما',
    },
    'q86hxt3x': {
      'en': 'Balance',
      'ar': 'الحساب',
    },
    'aoy7z6um': {
      'en': 'The Champion',
      'ar': 'البطل',
    },
    'hgfgu2th': {
      'en': 'VALID THRU',
      'ar': 'صالح  خلال',
    },
    '56qaiax1': {
      'en': '12/24',
      'ar': '12/22',
    },
    '3pa0xwpt': {
      'en': 'Vouchers Redeemed',
      'ar': 'القسائم المسترده',
    },
    'r4s9ke54': {
      'en': 'Youtube Plus Subscription',
      'ar': 'اشتراك يوتيوب بلس',
    },
    'fliiwlsq': {
      'en': '28 Jan, 12.30 AM',
      'ar': '28 يناير، الساعة 12.30 صباحًا',
    },
    '2fhvwnf8': {
      'en': '-120EGP',
      'ar': '-120 جنيه',
    },
    '2oxq4odz': {
      'en': 'History',
      'ar': 'تاريخ',
    },
    'znchyask': {
      'en': 'History',
      'ar': 'تاريخ',
    },
  },
  // Settings
  {
    'vxeo6dqb': {
      'en': 'General',
      'ar': 'عام',
    },
    'ru97rfw6': {
      'en': 'Language',
      'ar': 'اللغة',
    },
    '8l6hsuiv': {
      'en': 'Settings',
      'ar': 'الاعدادات',
    },
    'j7zzvled': {
      'en': 'Profile',
      'ar': 'حساب تعريفي',
    },
  },
  // MissionAdder
  {
    '8s5z0rmr': {
      'en': 'Task...',
      'ar': 'مهمة...',
    },
    '3jmsx7jt': {
      'en': 'Reward',
      'ar': 'جائزة',
    },
    'qcm6in8v': {
      'en': 'Times',
      'ar': 'مرات',
    },
    '2a9zlwuu': {
      'en': 'Add Mission',
      'ar': 'أضف مهمة',
    },
    'bp71hmtb': {
      'en': 'Or Add Voucher',
      'ar': 'أو إضافة قسيمة',
    },
    's6xs8eiw': {
      'en': 'Create Mission',
      'ar': 'إنشاء مهمة',
    },
    'yceptbcw': {
      'en': 'Please fill out the form below to continue.',
      'ar': 'يرجى ملء النموذج أدناه للمتابعة.',
    },
    'b8xcx9db': {
      'en': 'Home',
      'ar': 'الصفحة الرئيسية',
    },
  },
  // VoucherAdder
  {
    'zj9pnqj1': {
      'en': 'Voucher Provider Name',
      'ar': 'اسم موفر القسيمة',
    },
    'qtwax50x': {
      'en': 'Voucher Offer',
      'ar': 'عرض القسيمة',
    },
    'mzj2qufq': {
      'en': 'Voucher Offer Value',
      'ar': 'قيمة عرض القسيمة',
    },
    'v2py0vb8': {
      'en': 'Voucher Cost',
      'ar': 'تكلفة القسيمة',
    },
    'uyhq6639': {
      'en': 'Add Voucher',
      'ar': 'أضف قسيمة',
    },
    '69wpbtdu': {
      'en': 'Or Add Mission',
      'ar': 'أو أضف مهمة',
    },
    's3zr30wf': {
      'en': 'Create Voucher',
      'ar': 'إنشاء قسيمة',
    },
    'prnbc4qs': {
      'en': 'Please fill out the form below to continue.',
      'ar': 'يرجى ملء النموذج أدناه للمتابعة.',
    },
    'wdtj67o0': {
      'en': 'Home',
      'ar': 'الصفحة الرئيسية',
    },
  },
  // PointsRedeemer
  {
    'u2zi443w': {
      'en': 'CONGRATULATIONS',
      'ar': 'تهانينا',
    },
    'hjfd83oo': {
      'en': 'YOU HAVE CLAIMED YOUR',
      'ar': 'لقد استرددت',
    },
    '8fmefy4r': {
      'en': 'POINTS SUCCESSFULLY',
      'ar': 'النقاط بنجاح',
    },
  },
  // Miscellaneous
  {
    '5kvczae0': {
      'en': '',
      'ar': '',
    },
    'lkw7wpid': {
      'en': '',
      'ar': '',
    },
    'gaouu00f': {
      'en': '',
      'ar': '',
    },
    'l9bv8w2y': {
      'en': '',
      'ar': '',
    },
    '37ln4t77': {
      'en': '',
      'ar': '',
    },
    'rfz5veet': {
      'en': '',
      'ar': '',
    },
    'lyvwknmk': {
      'en': '',
      'ar': '',
    },
    'gpz7q227': {
      'en': '',
      'ar': '',
    },
    'ldv1wd2b': {
      'en': '',
      'ar': '',
    },
    'tjs0qjqi': {
      'en': '',
      'ar': '',
    },
    'rcp7dst7': {
      'en': '',
      'ar': '',
    },
    'kwztvpm2': {
      'en': '',
      'ar': '',
    },
    '480w1lmr': {
      'en': '',
      'ar': '',
    },
    'ecpwzumi': {
      'en': '',
      'ar': '',
    },
    'd8206btc': {
      'en': '',
      'ar': '',
    },
    'jthamj5c': {
      'en': '',
      'ar': '',
    },
    'zdsvhav0': {
      'en': '',
      'ar': '',
    },
    'gtkbubz2': {
      'en': '',
      'ar': '',
    },
    'opqpsyoy': {
      'en': '',
      'ar': '',
    },
    '90cjjcyj': {
      'en': '',
      'ar': '',
    },
    '6vlxdksw': {
      'en': '',
      'ar': '',
    },
    'v4s47xkb': {
      'en': '',
      'ar': '',
    },
    'i9dsbd4b': {
      'en': '',
      'ar': '',
    },
    '1idio4l4': {
      'en': '',
      'ar': '',
    },
    '4upm43q4': {
      'en': '',
      'ar': '',
    },
    '1j8h7b6l': {
      'en': '',
      'ar': '',
    },
    'yszcmufu': {
      'en': '',
      'ar': '',
    },
    'sdsv6cfd': {
      'en': '',
      'ar': '',
    },
  },
].reduce((a, b) => a..addAll(b));
